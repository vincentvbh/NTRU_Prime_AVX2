#include <stdio.h>

int main()
{
  printf("unknown CPU ID\n");
  return 0;
}
