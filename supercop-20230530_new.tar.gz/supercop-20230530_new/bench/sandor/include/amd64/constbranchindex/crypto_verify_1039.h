#ifndef crypto_verify_1039_H
#define crypto_verify_1039_H

#define crypto_verify_1039_avx_constbranchindex_BYTES 1039
 
#ifdef __cplusplus
extern "C" {
#endif
extern int crypto_verify_1039_avx_constbranchindex(const unsigned char *,const unsigned char *);
#ifdef __cplusplus
}
#endif

#define crypto_verify_1039 crypto_verify_1039_avx_constbranchindex
#define crypto_verify_1039_BYTES crypto_verify_1039_avx_constbranchindex_BYTES
#define crypto_verify_1039_IMPLEMENTATION "crypto_verify/1039/avx"
#ifndef crypto_verify_1039_avx_constbranchindex_VERSION
#define crypto_verify_1039_avx_constbranchindex_VERSION "-"
#endif
#define crypto_verify_1039_VERSION crypto_verify_1039_avx_constbranchindex_VERSION

#endif
