#ifndef crypto_rng_chacha20_H
#define crypto_rng_chacha20_H

#define crypto_rng_chacha20_ref_constbranchindex_KEYBYTES 32
#define crypto_rng_chacha20_ref_constbranchindex_OUTPUTBYTES 736
 
#ifdef __cplusplus
extern "C" {
#endif
extern int crypto_rng_chacha20_ref_constbranchindex(unsigned char *,unsigned char *,const unsigned char *);
#ifdef __cplusplus
}
#endif

#define crypto_rng_chacha20 crypto_rng_chacha20_ref_constbranchindex
#define crypto_rng_chacha20_KEYBYTES crypto_rng_chacha20_ref_constbranchindex_KEYBYTES
#define crypto_rng_chacha20_OUTPUTBYTES crypto_rng_chacha20_ref_constbranchindex_OUTPUTBYTES
#define crypto_rng_chacha20_IMPLEMENTATION "crypto_rng/chacha20/ref"
#ifndef crypto_rng_chacha20_ref_constbranchindex_VERSION
#define crypto_rng_chacha20_ref_constbranchindex_VERSION "-"
#endif
#define crypto_rng_chacha20_VERSION crypto_rng_chacha20_ref_constbranchindex_VERSION

#endif
