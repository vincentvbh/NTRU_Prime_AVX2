#ifndef crypto_sort_int32_H
#define crypto_sort_int32_H

#define crypto_sort_int32_avx2_constbranchindex_BYTES 4
 
#ifdef __cplusplus
extern "C" {
#endif
extern void crypto_sort_int32_avx2_constbranchindex(void *,long long);
#ifdef __cplusplus
}
#endif

#define crypto_sort_int32 crypto_sort_int32_avx2_constbranchindex
#define crypto_sort_int32_BYTES crypto_sort_int32_avx2_constbranchindex_BYTES
#define crypto_sort_int32_IMPLEMENTATION "crypto_sort/int32/avx2"
#ifndef crypto_sort_int32_avx2_constbranchindex_VERSION
#define crypto_sort_int32_avx2_constbranchindex_VERSION "-"
#endif
#define crypto_sort_int32_VERSION crypto_sort_int32_avx2_constbranchindex_VERSION

#endif
