#ifndef crypto_rng_aes256_H
#define crypto_rng_aes256_H

#define crypto_rng_aes256_ref_constbranchindex_KEYBYTES 32
#define crypto_rng_aes256_ref_constbranchindex_OUTPUTBYTES 736
 
#ifdef __cplusplus
extern "C" {
#endif
extern int crypto_rng_aes256_ref_constbranchindex(unsigned char *,unsigned char *,const unsigned char *);
#ifdef __cplusplus
}
#endif

#define crypto_rng_aes256 crypto_rng_aes256_ref_constbranchindex
#define crypto_rng_aes256_KEYBYTES crypto_rng_aes256_ref_constbranchindex_KEYBYTES
#define crypto_rng_aes256_OUTPUTBYTES crypto_rng_aes256_ref_constbranchindex_OUTPUTBYTES
#define crypto_rng_aes256_IMPLEMENTATION "crypto_rng/aes256/ref"
#ifndef crypto_rng_aes256_ref_constbranchindex_VERSION
#define crypto_rng_aes256_ref_constbranchindex_VERSION "-"
#endif
#define crypto_rng_aes256_VERSION crypto_rng_aes256_ref_constbranchindex_VERSION

#endif
