#ifndef crypto_declassify_h
#define crypto_declassify_h

extern void crypto_declassify(void *,unsigned long long);

#endif
