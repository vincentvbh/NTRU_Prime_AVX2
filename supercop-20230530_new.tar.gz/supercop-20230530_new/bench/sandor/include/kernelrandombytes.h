#ifndef kernelrandombytes_h
#define kernelrandombytes_h

#ifdef __cplusplus
extern "C" {
#endif

extern void kernelrandombytes(unsigned char *,unsigned long long);

#ifdef __cplusplus
}
#endif

#endif
