#define SMALL
#include "try.c"
