#include <openssl/rand.h>
#include <stddef.h>
#include <openssl/opensslv.h>
#define CRYPTO_VERSION OPENSSL_VERSION_TEXT
#define CRYPTO_BYTES 64
